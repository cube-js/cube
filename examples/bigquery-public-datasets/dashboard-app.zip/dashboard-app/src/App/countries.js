export const defaultCountries = [
    'United States',
    'India',
    'Brazil',
    'Russia',
    'United Kingdom',
    'France',
    'Spain',
    'Italy',
    'Turkey',
    'Germany'
]