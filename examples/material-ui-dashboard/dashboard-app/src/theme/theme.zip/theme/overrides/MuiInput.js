export default {
  underline: {
    '&:before': {
      borderBottom: '1px solid #D5D5E2',
    },
    '&&&&:hover:before': {
      borderBottom: '1px solid #A1A1B5',
    },
  },
};
