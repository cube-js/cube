import palette from '../palette';

export default {
  root: {
    backgroundColor: palette.primary.action,
  },
};
